package com.example.reversetheworld;

import com.mojang.logging.LogUtils;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.common.MinecraftForge;
import org.slf4j.Logger;

@Mod(ReverseTheWorldMod.MODID)
public class ReverseTheWorldMod {
    public static final String MODID = "reversetheworld";
    public static final Logger LOGGER = LogUtils.getLogger();

    public ReverseTheWorldMod() {
        MinecraftForge.EVENT_BUS.register(ReverseWorldHandler.INSTANCE);
    }
}