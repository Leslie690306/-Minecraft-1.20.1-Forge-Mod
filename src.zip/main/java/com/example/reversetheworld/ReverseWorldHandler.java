package com.example.reversetheworld;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.opengl.GL11;

@Mod.EventBusSubscriber(value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ReverseWorldHandler {

    public static final ReverseWorldHandler INSTANCE = new ReverseWorldHandler();

    private static final int SKILL_DURATION = 20 * 15; // 15秒（20tick = 1s）
    private static final int SKILL_COOLDOWN = 20 * 5; // 5秒

    private int skillTick = 0;
    private int cooldownTick = 0;
    private boolean reversed = false;

    // ===== F键触发技能 =====
    @SubscribeEvent
    public void onKey(InputEvent.Key event) {
        if (KeyBindings.REVERSE_KEY.consumeClick()) {
            if (!reversed && cooldownTick <= 0) {
                reversed = true;
                skillTick = SKILL_DURATION;
                cooldownTick = SKILL_DURATION + SKILL_COOLDOWN;
                sendMsg(Component.literal("倒转地球发动!"));
            } else if (cooldownTick > SKILL_DURATION) {
                sendMsg(Component.literal("技能冷却中..."));
            }
        }
    }

    // ===== 每tick 控制技能计时和冷却 =====
    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (event.phase != TickEvent.Phase.END || player == null) return;

        if (cooldownTick > 0) cooldownTick--;
        if (reversed) {
            skillTick--;
            // 移动方向反转
            reversePlayerControl(player);
            if (skillTick <= 0) {
                reversed = false;
                sendMsg(Component.literal("倒转地球结束!"));
            }
        }
    }

    // ===== 画面倒置特效 =====
    @SubscribeEvent
    public void onWorldRender(RenderLevelStageEvent event) {
        // 在Level渲染时画面倒置
        if (reversed && event.getStage() == RenderLevelStageEvent.Stage.AFTER_SKY) {
            // 画面整体GL旋转180度
            GL11.glPushMatrix();
            GL11.glRotated(180, 0, 0, 1);
        } else if (!reversed && event.getStage() == RenderLevelStageEvent.Stage.AFTER_SKY) {
            GL11.glPopMatrix();
        }
    }

    private void sendMsg(Component text) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.displayClientMessage(text, true);
    }

    // ===== 控制按键反转 =====
    private void reversePlayerControl(LocalPlayer player) {
        // 这里只模拟 W/S/A/D/跳 跳跃与下蹲反转
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.keyUp.isDown()) player.input.leftImpulse -= 1.0F; // W变成后退
        if (mc.options.keyDown.isDown()) player.input.leftImpulse += 1.0F; // S变成前进
        if (mc.options.keyLeft.isDown()) player.input.forwardImpulse += 1.0F; // A->D
        if (mc.options.keyRight.isDown()) player.input.forwardImpulse -= 1.0F; // D->A
        // 反转跳跃与潜行
        if (mc.options.keyJump.isDown()) player.setShiftKeyDown(true);
        if (mc.options.keyShift.isDown()) player.setJumping(true);
    }
}